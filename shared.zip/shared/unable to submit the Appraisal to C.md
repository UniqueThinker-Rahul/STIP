**unable to submit the Appraisal to CEO, issue :-⚠️ Error processing approval.**

**server rejecting the routing request and not generating log about the error/issue.**




2.server terminal error:-





PS D:\\STIP\_D\\backend> node .\\src\\server.js

◇ injected env (10) from .env // tip: ⌘ enable debugging { debug: true }

✅ Connected to MongoDB Atlas Cloud Production Ready.

🚀 API Engine online on port 5000

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(Use `node --trace-warnings ...` to show where the warning was created)

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.

(node:73536) \[MONGOOSE] Warning: mongoose: the `new` option for `findOneAndUpdate()` and `findOneAndReplace()` is deprecated. Use `returnDocument: 'after'` instead.









1\. browser console error:-



Download the React DevTools for a better development experience: https://react.dev/link/react-devtools

forward-logs-shared.ts:95 \[HMR] connected

page.js:74  PATCH http://localhost:5000/api/v1/appraisals/6a11687e2c0de3435f8756f2/approve 500 (Internal Server Error)

dispatchXhrRequest @ xhr.js:225

(anonymous) @ xhr.js:17

dispatchRequest @ dispatchRequest.js:48

Promise.then

\_request @ Axios.js:196

request @ Axios.js:41

httpMethod @ Axios.js:257

wrap @ bind.js:12

(anonymous) @ page.js:74

(anonymous) @ page.js:381

executeDispatch @ react-dom-client.development.js:20610

runWithFiberInDEV @ react-dom-client.development.js:986

processDispatchQueue @ react-dom-client.development.js:20660

(anonymous) @ react-dom-client.development.js:21234

batchedUpdates$1 @ react-dom-client.development.js:3377

dispatchEventForPluginEventSystem @ react-dom-client.development.js:20814

dispatchEvent @ react-dom-client.development.js:25817

dispatchDiscreteEvent @ react-dom-client.development.js:25785



