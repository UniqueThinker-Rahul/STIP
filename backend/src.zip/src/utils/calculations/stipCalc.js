// CY Award calculation
