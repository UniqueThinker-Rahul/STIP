// IPRF calculation
