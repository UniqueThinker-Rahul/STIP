// MongoDB connection logic
