// Appraisal module
